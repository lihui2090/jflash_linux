#ifndef __SJF_H__
#define __SJF_H__

int LoadImageFile(U8 *buf,int size);

extern U32 imageSize;

#endif //__SJF_H__

